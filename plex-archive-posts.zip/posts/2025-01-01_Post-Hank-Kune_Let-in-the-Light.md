---
title: "Let in the Light"
author: "Hank Kune"
issue_slug: "2025-01-01"
tags: []
---

# Let in the Light

**Author:** [[Hank Kune]]
**Issue:** [2025-01-01](https://plex.collectivesensecommons.org/2025-01-01/)

---

## Let in the Light
by **Hank Kune**

I took a walk in the winter woods
on the last day of the old year.
There was space for reflection there.

Then the clouds shifted their focus
and let in the sun.
More room for the sun, I thought,
That’s what the forest needs.

The trees will shine in the light, I see,
and so will we.

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Hank Kune]] (author)
- [[2025]] (year)
- Topics: 

