---
title: "My First Time at the Pool"
author: "Ken Homer"
issue_slug: "2024-10-16"
tags: []
---

# My First Time at the Pool

**Author:** [[Ken Homer]]
**Issue:** [2024-10-16](https://plex.collectivesensecommons.org/2024-10-16/)

---

## My First Time at the Pool
by **Ken Homer**

One evening my eldest sister
Took me to her friend’s house
I might have been about two
There was a pool
It was all lit up from below
I was mesmerized
I immediately walked into the water
It was the deep end
I remember warm water
Opening my eyes to the blue light
Loving the feeling of floating

Then there was a problem
I didn't know how to swim
l inhaled water
started to cough
Started to panic
The sinking feeling inside
Was accompanied by
My body sinking to the bottom

Suddenly a pair of hands
Was under my arms
I was being lifted up
Out of the water
Able to breathe air
Still coughing and sputtering
I didn't cry
Not at first
But once I was okay
I got scared
Started wailing
That's all I recall

Ken Homer • February 2024

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

