---
title: "ReSource Patchwork Urban Farms"
author: "Kevin Jones"
issue_slug: "2022-06-15"
tags: []
---

# ReSource Patchwork Urban Farms

**Author:** [[Kevin Jones]]
**Issue:** [2022-06-15](https://plex.collectivesensecommons.org/2022-06-15/)

---

## ReSource; Patchwork Urban Farms
by **Kevin Jones**

We are looking to integrate our venture philanthropy dollars on our multidonor marketplace with that of a barter-on-the-blockchain, mutual credit startup called [ReSource](https://resource.finance/). They are on the [Celo](https://celo.org/) chain. We are also working with [Patchwork Urban Farms](https://www.patchworkurbanfarms.com/why-patchwork), a local producer, consumer and worker coop, that is also integrating with ReSource, to see what we might do together.

---

**Related:**
- [[Kevin Jones]] (author)
- [[2022]] (year)
- Topics: 

