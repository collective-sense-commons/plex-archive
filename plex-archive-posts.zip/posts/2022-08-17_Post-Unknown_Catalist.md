---
title: "Catalist"
author: "Unknown"
issue_slug: "2022-08-17"
tags: []
---

# Catalist

**Author:** [[Unknown]]
**Issue:** [2022-08-17](https://plex.collectivesensecommons.org/2022-08-17/)

---

## Catalist
Create a free account by clicking on “Beta Signup” on the Catalist home page. If you need help, email [catalist.network@gmail.com](mailto:catalist.network@gmail.com).

Catalist is one of the core directories for communities in the Plex, along with many other groups, project, and events.  Use the “Explore” menu to get an idea of who, what, and where around Plex, and let the Catalist team know what you think.

---

**Related:**
- [[Unknown]] (author)
- [[2022]] (year)
- Topics: 

