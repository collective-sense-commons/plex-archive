---
title: "Antidote for a Techno-Optimist Manifesto"
author: "Peter Kaminski"
issue_slug: "2023-10-18"
tags: []
---

# Antidote for a Techno-Optimist Manifesto

**Author:** [[Peter Kaminski]]
**Issue:** [2023-10-18](https://plex.collectivesensecommons.org/2023-10-18/)

---

## Antidote for a “Techno-Optimist Manifesto”
by **Peter Kaminsk**i

Marc Andreessen wrote a “Techno-Optimist Manifesto,” for which some of us might need an antidote. I like [Vesna Manojlovic's short note](https://nettime.org/Lists-Archives/nettime-l-2310/msg00087.html), via nettime-l. The typography isn't as pretty as Andreessen's, but the message is more wholesome.

Manojlovic includes links to additional resources sprinkled throughout her email.

*Nettime-l recently moved servers and their published subscribe link is broken. I think this is the new one: [https://lists.servus.at/mailman/listinfo/nettime-l*](https://lists.servus.at/mailman/listinfo/nettime-l)

---

**Related:**
- [[Peter Kaminski]] (author)
- [[2023]] (year)
- Topics: 

