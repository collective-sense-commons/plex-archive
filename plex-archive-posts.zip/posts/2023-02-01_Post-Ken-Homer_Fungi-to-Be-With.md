---
title: "Fungi to Be With"
author: "Ken Homer"
issue_slug: "2023-02-01"
tags: []
---

# Fungi to Be With

**Author:** [[Ken Homer]]
**Issue:** [2023-02-01](https://plex.collectivesensecommons.org/2023-02-01/)

---

## Fungi to Be With
by **Ken Homer**

Some fungi to be with 😉 – the recent rains led to a bumper crop!

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

