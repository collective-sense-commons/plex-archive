---
title: "Hiking Red Rocks Open Space"
author: "Patti Cobian"
issue_slug: "2024-05-01"
tags: []
---

# Hiking Red Rocks Open Space

**Author:** [[Patti Cobian]]
**Issue:** [2024-05-01](https://plex.collectivesensecommons.org/2024-05-01/)

---

## Hiking Red Rocks Open Space
by **Patti Cobian**

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Patti Cobian]] (author)
- [[2024]] (year)
- Topics: 

