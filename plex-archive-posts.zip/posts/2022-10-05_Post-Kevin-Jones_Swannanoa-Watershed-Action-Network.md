---
title: "Swannanoa Watershed Action Network"
author: "Kevin Jones"
issue_slug: "2022-10-05"
tags: ['Bioregionalism and Place-Based Practice']
---

# Swannanoa Watershed Action Network

**Author:** [[Kevin Jones]]
**Issue:** [2022-10-05](https://plex.collectivesensecommons.org/2022-10-05/)

---

## Swannanoa Watershed Action Network
by **Kevin Jones**

We have started to interview all the non profits who got grants from the local community foundation in order to establish a baseline of the social safety net.

In addition, teams are doing riparian clean up of trash a couple of times a week, and two town council candidates from Black Mountain have joined our Swannanoa Watershed Action Network (SWAN).

---

**Related:**
- [[Kevin Jones]] (author)
- [[2022]] (year)
- Topics: [[Bioregionalism and Place-Based Practice]]

