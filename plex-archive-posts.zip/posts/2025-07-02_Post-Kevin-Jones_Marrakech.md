---
title: "Marrakech"
author: "Kevin Jones"
issue_slug: "2025-07-02"
tags: []
---

# Marrakech

**Author:** [[Kevin Jones]]
**Issue:** [2025-07-02](https://plex.collectivesensecommons.org/2025-07-02/)

---

## Marrakech
by **Kevin Jones**

*Kevin and Rosa Lee have been traveling in Europe and North Africa for two months. They're now on their way back to the States.*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Kevin Jones]] (author)
- [[2025]] (year)
- Topics: 

