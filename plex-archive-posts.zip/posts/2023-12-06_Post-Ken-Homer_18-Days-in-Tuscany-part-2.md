---
title: "18 Days in Tuscany, part 2"
author: "Ken Homer"
issue_slug: "2023-12-06"
tags: []
---

# 18 Days in Tuscany, part 2

**Author:** [[Ken Homer]]
**Issue:** [2023-12-06](https://plex.collectivesensecommons.org/2023-12-06/)

---

## 18 Days in Tuscany, part 2
by **Ken Homer**

More pix from Italy!

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

