---
title: "PLEXLINKS 20230906"
author: "Charles Blass"
issue_slug: "2023-09-06"
tags: []
---

# PLEXLINKS 20230906

**Author:** [[Charles Blass]]
**Issue:** [2023-09-06](https://plex.collectivesensecommons.org/2023-09-06/)

---

## PLEXLINKS 20230906
by **charles blass**

hey plexers, in lieu of images this issue i offer a few scoops of compost fresh from top of the heap, such cheery times we’re in, keep breathing, & blinking .... love, cb

Systemic Drivers of Collapse (Part 2 – An Overview) (Tom Atlee 20230905)
[https://www.tomatleeblog.com/archives/175328772](https://www.tomatleeblog.com/archives/175328772)

torres & gebru: what’s behind the race to create agi (aug. 2023)
[https://youtu.be/-bKrMk0RSwY](https://youtu.be/-bKrMk0RSwY?si=cLTQhwYdmxoKayGt)

timnit gebru: eugenics and the promise of utopia through artificial general intelligence (feb. 2023)
[https://youtu.be/P7XT4TWLzJw](https://youtu.be/P7XT4TWLzJw)

emily bender: ChatGP-why: When, if ever, is synthetic text safe, appropriate, and desirable? (20230808)
[https://youtube.com/watch?v=qpE40jwMilU](https://youtube.com/watch?v=qpE40jwMilU&feature=sharec)

Rhetoric of AI Hype w/ Emily Bender (july 2023)
[https://youtu.be/18Ppy70F66M](https://youtu.be/18Ppy70F66M?si=jXOsXFCxG-nWpJrp)

AI could choke on its own exhaust as it fills the web (20230828)
[https://www.axios.com/2023/08/28/ai-content-flood-model-collapse](https://www.axios.com/2023/08/28/ai-content-flood-model-collapse)

The Hidden History of the Like Button: From Decentralized Data to Semantic Enclosure (aug. 2023)
[https://journals.sagepub.com/doi/10.1177/20563051231195542](https://journals.sagepub.com/doi/10.1177/20563051231195542)
[https://vimeo.com/775826302](https://vimeo.com/775826302)
(nov. 2022)

How Musk, Thiel, Zuckerberg, and Andressen Are Creating an Alternate, Autocratic Reality (Aug. 2023)
[https://www.vanityfair.com/news/2023/08/musk-thiel-zuckerberg-andreessen-alternate-autocratic-reality](https://www.vanityfair.com/news/2023/08/musk-thiel-zuckerberg-andreessen-alternate-autocratic-reality)

Nate Hagens presentation on energy - GITA series (feb. 2023)
[https://youtu.be/iTxEPqjfdyk](https://youtu.be/iTxEPqjfdyk?si=mGNIhlrF0Lxi72cD)

How AI Researcher Dylan Baker Uses Technical Communication to Reduce Algorithmic Harm (june 2023)
[https://cchange.xyz/dylan-baker/](https://cchange.xyz/dylan-baker/)

datasets have worldviews - dylan baker (jan. 2022)
[https://pair.withgoogle.com/explorables/dataset-worldviews/](https://pair.withgoogle.com/explorables/dataset-worldviews/)

AI and Stochastic Parrots: Emily Bender & Timnit Gebru (Apr. 2023)
[https://youtu.be/jAHRbFetqII](https://youtu.be/jAHRbFetqII)

timnit gebru: is ai racist and anti-democractic? (aug. 2022)
[https://youtu.be/vUJVzIdRSnQ](https://youtu.be/vUJVzIdRSnQ?si=dfWe-2cT5Piq6evE)

Ethical AI - Timnit Gebru & Minerva Tantoco (Oct. 2022)
[https://youtu.be/gDVg_nnOCFE](https://youtu.be/gDVg_nnOCFE)

Seeing Silicon Valley: Fred Turner & Mary Beth Meehan (may 2022)
[https://youtu.be/NmSN3g49Als](https://youtu.be/NmSN3g49Als?si=1f7tyEByK2PJ1UIe)
[audio not great, but good discussion]

geert lovink: the dark side of the net (dec. 2020)
[https://youtu.be/rkutZyxO5WU](https://youtu.be/rkutZyxO5WU?si=5GJU3Glhc8aGgNBk)
[https://networkcultures.org/](https://networkcultures.org/)

killer thread
‘meaning of “open” in so-called “open” AI including “OpenAI”’
[https://twitter.com/criticalai/status/1699497483976519705](https://twitter.com/criticalai/status/1699497483976519705)
[https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4543807](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4543807)

---

**Related:**
- [[Charles Blass]] (author)
- [[2023]] (year)
- Topics: 

