---
title: "Remembrances from 1960"
author: "Ken Homer"
issue_slug: "2024-11-06"
tags: []
---

# Remembrances from 1960

**Author:** [[Ken Homer]]
**Issue:** [2024-11-06](https://plex.collectivesensecommons.org/2024-11-06/)

---

## Remembrances from 1960
by **Ken Homer**

### The Census
Although I was only three
I remember the 1960 census
A nice woman came to the door
She asked my mom a lot of questions
I fleshed out her answers
Providing details
I felt she glossed over
After the woman left
I was rewarded with
A visit from the hairbrush

### The Presidential Election
Who won?
I asked my dad
The morning after
The 1960 election
His face fell
Kennedy
He spat the name
More than spoke it
Yay! Said me
Even at the tender
Age of three
There was something
About Richard Nixon
That I didn't like

Ken Homer • February 2024

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

