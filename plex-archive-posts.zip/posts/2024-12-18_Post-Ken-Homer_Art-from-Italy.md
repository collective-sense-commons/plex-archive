---
title: "Art from Italy"
author: "Ken Homer"
issue_slug: "2024-12-18"
tags: []
---

# Art from Italy

**Author:** [[Ken Homer]]
**Issue:** [2024-12-18](https://plex.collectivesensecommons.org/2024-12-18/)

---

## Art from Italy
by **Ken Homer**

### In the Men’s Room of a Restaurant in Lucca

*[Image not included in the current archive. Images may be included in the future.]*

### Nice Knockers!

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

