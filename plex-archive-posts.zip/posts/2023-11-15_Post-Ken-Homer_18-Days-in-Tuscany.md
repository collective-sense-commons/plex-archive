---
title: "18 Days in Tuscany"
author: "Ken Homer"
issue_slug: "2023-11-15"
tags: []
---

# 18 Days in Tuscany

**Author:** [[Ken Homer]]
**Issue:** [2023-11-15](https://plex.collectivesensecommons.org/2023-11-15/)

---

## 18 Days in Tuscany
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

