---
title: "Park Landscape in February"
author: "Hank Kune"
issue_slug: "2023-02-15"
tags: []
---

# Park Landscape in February

**Author:** [[Hank Kune]]
**Issue:** [2023-02-15](https://plex.collectivesensecommons.org/2023-02-15/)

---

## Park Landscape in February

The healing sun
Woods without a breeze
A song to share
The Earth that breathes

We who care
What others see
May enter here
Among the trees

As light lightens us.
Park landscape in February.

– Hank Kune

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Hank Kune]] (author)
- [[2023]] (year)
- Topics: 

