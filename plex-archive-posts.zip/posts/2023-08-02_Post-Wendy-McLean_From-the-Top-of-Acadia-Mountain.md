---
title: "From the Top of Acadia Mountain"
author: "Wendy McLean"
issue_slug: "2023-08-02"
tags: []
---

# From the Top of Acadia Mountain

**Author:** [[Wendy McLean]]
**Issue:** [2023-08-02](https://plex.collectivesensecommons.org/2023-08-02/)

---

## From the Top of Acadia Mountain
by **Wendy McLean**

*Ed. note–Wendy is readying a post for a future edition of the Plex. In the meantime, she forwards us this lovely photo.*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Wendy McLean]] (author)
- [[2023]] (year)
- Topics: 

