---
title: "Big Red Tugboat"
author: "Ken Homer"
issue_slug: "2023-01-18"
tags: []
---

# Big Red Tugboat

**Author:** [[Ken Homer]]
**Issue:** [2023-01-18](https://plex.collectivesensecommons.org/2023-01-18/)

---

## Big Red Tugboat
by **Ken Homer**

*Some pix taken of or from my friend’s big red tugboat–sadly they sold it. 😢*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

