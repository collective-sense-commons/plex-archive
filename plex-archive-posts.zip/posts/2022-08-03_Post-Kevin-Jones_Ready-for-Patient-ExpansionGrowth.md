---
title: "Ready for Patient ExpansionGrowth Capital?"
author: "Kevin Jones"
issue_slug: "2022-08-03"
tags: []
---

# Ready for Patient ExpansionGrowth Capital?

**Author:** [[Kevin Jones]]
**Issue:** [2022-08-03](https://plex.collectivesensecommons.org/2022-08-03/)

---

## Ready for Patient Expansion/Growth Capital?
by **Kevin Jones**

Our community-wide philanthropic investing marketplace is actively connecting with nonprofits with earned income, who are ready for patient expansion / growth capital, to be paid back through revenue share.

We are also in api negotiations to create a local, for-profit crowdfunding marketplace.

*To connect with Kevin, send an email to [Pete](mailto:kaminski@istori.com).*

---

**Related:**
- [[Kevin Jones]] (author)
- [[2022]] (year)
- Topics: 

