---
title: "Bush Office"
author: "Wendy Elford"
issue_slug: "2024-05-01"
tags: []
---

# Bush Office

**Author:** [[Wendy Elford]]
**Issue:** [2024-05-01](https://plex.collectivesensecommons.org/2024-05-01/)

---

## Bush Office
by **Wendy Elford**

*(ed. note: For American readers, the Australian word “bush” means more or less “wilderness”.)*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Wendy Elford]] (author)
- [[2024]] (year)
- Topics: 

