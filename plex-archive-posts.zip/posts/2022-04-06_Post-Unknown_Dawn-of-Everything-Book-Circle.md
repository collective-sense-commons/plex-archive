---
title: "Dawn of Everything Book Circle"
author: "Unknown"
issue_slug: "2022-04-06"
tags: []
---

# Dawn of Everything Book Circle

**Author:** [[Unknown]]
**Issue:** [2022-04-06](https://plex.collectivesensecommons.org/2022-04-06/)

---

## “Dawn of Everything” Book Circle
A group of Plex folks are getting together to support each other in reading **The Dawn of Everything,** an important book by anthropologist David Graeber and archaeologist David Wengrow. They’ve had two organizational meetings, and are now scheduling their Chapter 1 calls for next week. See their website, [Dawn of Everything Book Circle](https://doe.bookcircle.academy/) and visit the mattermost channel, [Dawn of Everything](https://chat.collectivesensecommons.org/agora/channels/dawn-of-everything).

---

**Related:**
- [[Unknown]] (author)
- [[2022]] (year)
- Topics: 

