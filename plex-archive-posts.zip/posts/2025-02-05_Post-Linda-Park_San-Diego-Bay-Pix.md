---
title: "San Diego Bay Pix"
author: "Linda Park"
issue_slug: "2025-02-05"
tags: []
---

# San Diego Bay Pix

**Author:** [[Linda Park]]
**Issue:** [2025-02-05](https://plex.collectivesensecommons.org/2025-02-05/)

---

## San Diego Bay Pix
by **Linda Park**

*Images of San Diego Bay, including the USS Midway and another across the bay. – Jack*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Linda Park]] (author)
- [[2025]] (year)
- Topics: 

