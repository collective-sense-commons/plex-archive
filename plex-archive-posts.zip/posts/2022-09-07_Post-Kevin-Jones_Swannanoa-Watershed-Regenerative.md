---
title: "Swannanoa Watershed Regenerative Initiative"
author: "Kevin Jones"
issue_slug: "2022-09-07"
tags: ['Bioregionalism and Place-Based Practice']
---

# Swannanoa Watershed Regenerative Initiative

**Author:** [[Kevin Jones]]
**Issue:** [2022-09-07](https://plex.collectivesensecommons.org/2022-09-07/)

---

## Swannanoa Watershed Regenerative Initiative
by **Kevin Jones**

The **Swannanoa Watershed Regenerative Initiative** is looking for a space in Black Mountain, North Carolina to be a home for our **watershed asset mapping.**

We are also hiring a **system entrepreneur part time.**

*[Pete](mailto:kaminski@istori.com) can put you in touch with Kevin Jones.*

---

**Related:**
- [[Kevin Jones]] (author)
- [[2022]] (year)
- Topics: [[Bioregionalism and Place-Based Practice]]

