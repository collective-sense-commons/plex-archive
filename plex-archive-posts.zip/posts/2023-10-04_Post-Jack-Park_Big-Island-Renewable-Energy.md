---
title: "Big Island Renewable Energy"
author: "Jack Park"
issue_slug: "2023-10-04"
tags: []
---

# Big Island Renewable Energy

**Author:** [[Jack Park]]
**Issue:** [2023-10-04](https://plex.collectivesensecommons.org/2023-10-04/)

---

## Big Island Renewable Energy
by **Jack Park**

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

When you are studying geo locations for wind energy and you see trees growing sideways in the same direction, it's not just leaning in the wind. Rather, it's so windy the trees do not grow tall but lay low. That's *carpeting*–a dead giveaway. Usually, that also means it's not a place you'd like to live.

---

**Related:**
- [[Jack Park]] (author)
- [[2023]] (year)
- Topics: 

