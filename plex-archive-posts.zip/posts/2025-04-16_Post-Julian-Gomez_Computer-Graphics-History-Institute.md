---
title: "Computer Graphics History Institute"
author: "Julian Gómez"
issue_slug: "2025-04-16"
tags: []
---

# Computer Graphics History Institute

**Author:** [[Julian Gómez]]
**Issue:** [2025-04-16](https://plex.collectivesensecommons.org/2025-04-16/)

---

## Computer Graphics History Institute
by **Julian Gómez**

The Center for Computer Graphics History held its first board meeting on April 11. One outcome was to rename the center to the **Computer Graphics History Institute.** With the bylaws approved, the Institute will begin operations soon.

---

**Related:**
- [[Julian Gómez]] (author)
- [[2025]] (year)
- Topics: 

