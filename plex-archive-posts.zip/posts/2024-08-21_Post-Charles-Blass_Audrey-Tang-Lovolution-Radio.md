---
title: "Audrey Tang  Lovolution Radio"
author: "Charles Blass"
issue_slug: "2024-08-21"
tags: []
---

# Audrey Tang  Lovolution Radio

**Author:** [[Charles Blass]]
**Issue:** [2024-08-21](https://plex.collectivesensecommons.org/2024-08-21/)

---

## Audrey Tang / Lovolution Radio
h/t **Charles Blass**

*Charles offers two treats for this issue – ed.*

### endlossounds: Lovolution
A rare daytime set at the summer radio festival from Radio LoRa in Zurich.

Radio LoRa overview: [Lovolution](https://endlos.lora.ch/lovolution/)

Playback: [endlossounds: Lovolution](https://www.lora.ch/radio/ausgaben/endlossounds-lovolution-2024-08-15)

### Audrey Tang in Zurich
“amazing session with the great audrey tang this month in ztown – all around remarkable discussion, moderation, questions/ audience – a veritable rosetta stone of blueprints”

OpenData.ch overview:

[Audrey Tang: Plurality - The Future of Collaborative Technology and Democracy](https://opendata.ch/events/plurality-with-audrey-tang/)

YouTube:

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Charles Blass]] (author)
- [[2024]] (year)
- Topics: 

