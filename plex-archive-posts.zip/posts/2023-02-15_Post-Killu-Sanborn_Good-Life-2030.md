---
title: "Good Life 2030"
author: "Killu Sanborn"
issue_slug: "2023-02-15"
tags: []
---

# Good Life 2030

**Author:** [[Killu Sanborn]]
**Issue:** [2023-02-15](https://plex.collectivesensecommons.org/2023-02-15/)

---

## Good Life 2030
by **Killu Sanborn**

I heard through a friend about [**Good Life 2030**](https://www.goodlife2030.earth/). The project went around the UK and interviewed people to ask what “good life” means to them.

Their short, 15-minute documentary really gives me hope, as it is done by ad industry execs and is about using advertising for Good, rather than for driving wasteful consumption.

Check it out:

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Killu Sanborn]] (author)
- [[2023]] (year)
- Topics: 

