---
title: "Among The Redwoods"
author: "Ken Homer"
issue_slug: "2023-10-18"
tags: []
---

# Among The Redwoods

**Author:** [[Ken Homer]]
**Issue:** [2023-10-18](https://plex.collectivesensecommons.org/2023-10-18/)

---

## Among The Redwoods
by **Ken Homer**

A few pix from my hikes in the redwoods.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

