---
title: "What I Saw Around Town"
author: "Ken Homer"
issue_slug: "2023-08-16"
tags: []
---

# What I Saw Around Town

**Author:** [[Ken Homer]]
**Issue:** [2023-08-16](https://plex.collectivesensecommons.org/2023-08-16/)

---

## What I Saw Around Town
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

