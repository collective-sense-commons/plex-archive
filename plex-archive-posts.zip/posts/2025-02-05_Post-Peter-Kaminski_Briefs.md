---
title: "Briefs"
author: "Peter Kaminski"
issue_slug: "2025-02-05"
tags: []
---

# Briefs

**Author:** [[Peter Kaminski]]
**Issue:** [2025-02-05](https://plex.collectivesensecommons.org/2025-02-05/)

---

## Briefs
### Julian Gómez
Design for a new LLM: the Parent LLM. When you ask it what its reasoning is, it replies “Because I said so.”

### Patti Cobian
I am experimenting with (at least) one month of no news, social media, or social gatherings outside of the regularly scheduled programming and business arrangements. All of that energy has been channeled into writing my first book. If a first draft buds by the end of the month, I might just do it all over again. Feeling: fierce and hopeful.

### Peter Kaminski
YouBots.ai and AICoaching.Forum are both launching real soon now, which is why you haven’t seen me much! Checking in, I’m happy about: family, and oddly, AI. I’m concerned about: tariffs. Er, USAID. Carrot/stick RIF? Uh, Treasury payments...

---

**Related:**
- [[Peter Kaminski]] (author)
- [[2025]] (year)
- Topics: 

