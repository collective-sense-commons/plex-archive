---
title: "Green and Blue"
author: "Ken Homer"
issue_slug: "2023-07-05"
tags: []
---

# Green and Blue

**Author:** [[Ken Homer]]
**Issue:** [2023-07-05](https://plex.collectivesensecommons.org/2023-07-05/)

---

## Green and Blue
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

