---
title: "Three Pieces of Folk Wisdom"
author: "Ken Homer"
issue_slug: "2025-08-20"
tags: []
---

# Three Pieces of Folk Wisdom

**Author:** [[Ken Homer]]
**Issue:** [2025-08-20](https://plex.collectivesensecommons.org/2025-08-20/)

---

## Three Pieces of Folk Wisdom
by **Ken Homer**

### The Circularity of Learning
~ Author unknown

A young person goes to an elder and asks how to obtain wisdom.
The teacher thinks for a moment and says: By exercising good judgment.
The young person asks how to obtain good judgment.
The elder replies: By gaining experience.
The young person asks how to obtain experience.
The elder smiles and tells them: By exercising bad judgment.

••••••••••••••

### How the Times Produce People
~ Authorship disputed

Hard times create strong people
Strong people create easy times
Easy times create soft people
Soft people create hard times

••••••••••••••

### When Is It a True Dawn?
~ Author unknown

A teacher asked his young charges:
How can you tell when it is a true dawn?
The first one answered: When you can distinguish the mountains from the foothills.
Ah, a good answer, but not what I am looking for.
The second one answered: When you can tell a ram from a ewe.
Another good answer, but still not what I am looking for.
The third one answered: When you can read the lines in the palm of your hand.
Yet another good reply and still not what I am looking for.
No one else had an answer and someone asked: So how can we tell when it is a true dawn?
The teacher answered: When you look into the eyes of another and see yourself. Then you will know that it is a true dawn.

---

**Related:**
- [[Ken Homer]] (author)
- [[2025]] (year)
- Topics: 

