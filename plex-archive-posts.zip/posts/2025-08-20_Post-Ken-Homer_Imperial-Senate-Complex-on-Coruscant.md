---
title: "Imperial Senate Complex on Coruscant"
author: "Ken Homer"
issue_slug: "2025-08-20"
tags: []
---

# Imperial Senate Complex on Coruscant

**Author:** [[Ken Homer]]
**Issue:** [2025-08-20](https://plex.collectivesensecommons.org/2025-08-20/)

---

## Imperial Senate Complex on Coruscant
by **Ken Homer**

*From one of Ken's recent trips. – Pete*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2025]] (year)
- Topics: 

