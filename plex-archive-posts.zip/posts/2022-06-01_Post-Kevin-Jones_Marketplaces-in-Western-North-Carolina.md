---
title: "Marketplaces in Western North Carolina"
author: "Kevin Jones"
issue_slug: "2022-06-01"
tags: []
---

# Marketplaces in Western North Carolina

**Author:** [[Kevin Jones]]
**Issue:** [2022-06-01](https://plex.collectivesensecommons.org/2022-06-01/)

---

## Marketplaces in Western North Carolina
by **Kevin Jones**

We are moving into wireframe ideation for the two marketplaces we are building in **Western North Carolina.** One marketplace is a multi-donor donor-advised fund platform for philanthropic investing; **venture philanthropy.** The other marketplace is an aggregation of the four successful **online equity crowdfunding** for local businesses.

---

**Related:**
- [[Kevin Jones]] (author)
- [[2022]] (year)
- Topics: 

