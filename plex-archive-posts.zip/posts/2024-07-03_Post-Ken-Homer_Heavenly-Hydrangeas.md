---
title: "Heavenly Hydrangeas"
author: "Ken Homer"
issue_slug: "2024-07-03"
tags: []
---

# Heavenly Hydrangeas

**Author:** [[Ken Homer]]
**Issue:** [2024-07-03](https://plex.collectivesensecommons.org/2024-07-03/)

---

## Heavenly Hydrangeas
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

