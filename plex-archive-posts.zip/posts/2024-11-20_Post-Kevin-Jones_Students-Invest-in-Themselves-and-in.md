---
title: "Students Invest in Themselves and in Their Dreams"
author: "Kevin Jones"
issue_slug: "2024-11-20"
tags: []
---

# Students Invest in Themselves and in Their Dreams

**Author:** [[Kevin Jones]]
**Issue:** [2024-11-20](https://plex.collectivesensecommons.org/2024-11-20/)

---

## Students Invest in Themselves and in Their Dreams
by **Kevin Jones**

We are launching a currency within [Warren Wilson College](https://www.warren-wilson.edu/) whereby students can invest philanthropically in themselves and in the ideas they want to see become reality.

It's done through a localizable low-cost philanthropic investment platform we are representing, with services for the investee and investor to be determined.

The Warren Wilson economist says the currency will start in the student store. They are already using sticks as a kind of central bank.

 If you squint, you can almost believe it’s real.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Kevin Jones]] (author)
- [[2024]] (year)
- Topics: 

