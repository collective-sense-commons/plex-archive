---
title: "Earth Remembering"
author: "Patti Cobian"
issue_slug: "2025-01-01"
tags: []
---

# Earth Remembering

**Author:** [[Patti Cobian]]
**Issue:** [2025-01-01](https://plex.collectivesensecommons.org/2025-01-01/)

---

## Earth Remembering
by **Patti Cobian**

*This piece came through as a response to the fear and anxiety that has arisen since the results of the election (though can probably be applied to other matters).*

*[Image not included in the current archive. Images may be included in the future.]*

### Earth Remembering
The day came and went,
and as for the Earth,
She paid little mind

Do you think, She said,
that I have not known this?
That I do not beat in every heart
that beats in mine?

I call to you
I call to each and every one of you
And though you may think
there are hearts too dead
to hear my call,
you, too, have forgotten

that my heart beats
in every body
and every blade.
You have forgotten
my wisdom
Or maybe you have never known

what it is
that I do
in dreams
and sleep

in idle thoughts
and quickened heartbeats

Your simple minds
cannot hold
the ends
of a billion threads

And you forget your place
when you try
You forget my place
when you try

A planetary virus
is not a wrongness
But you mistake the symptoms
for your business

Come back to me, She says,
I am alive in you
and I call to you

I call you back to your joy
so that you may feel your grief
I call you back to your heart
so that you may sleep

and rise to meet me in your wisdom
and not your fear
where you are of no use to me.

Yours is not a battle of mind, you see
It never was
nor will it ever be
anything more
than a clarion call
to your remembering

---

**Related:**
- [[Patti Cobian]] (author)
- [[2025]] (year)
- Topics: 

