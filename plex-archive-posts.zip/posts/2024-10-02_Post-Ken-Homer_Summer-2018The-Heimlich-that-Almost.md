---
title: "Summer 2018The Heimlich that Almost Failed"
author: "Ken Homer"
issue_slug: "2024-10-02"
tags: []
---

# Summer 2018The Heimlich that Almost Failed

**Author:** [[Ken Homer]]
**Issue:** [2024-10-02](https://plex.collectivesensecommons.org/2024-10-02/)

---

## Summer 2018–The Heimlich that Almost Failed
by **Ken Homer**

My friend Michael puts on
A hellava party every summer.
Between 70 and 100 people
Show up each year, gathering
in his backyard for food and fun
and music and wine and laughter.
Weed is plentiful too.

Everyone brings a yummy dish
and a favorite bottle to share.
Michael provides the oysters.
By the end of the party
two trash cans are filled with shells.
We eat em raw and BBQ’d.
They spent the previous night
sleeping in the mud of Tomales Bay.

On this particular day,
I was sitting on the side porch
of the second home on the property
out of sight from Michael’s house.
I was chatting with some friends and
enjoying my second glass of wine.
I had a couple of hits off a joint
that was being passed around
and was enjoying a nice buzz.

Just then a woman appeared...
“I need the strongest guy here!
There’s a man who is choking to death!”
I sprung out of my chair and followed.
There in the middle of the yard
stood a man of tremendous girth.

Behind him stood a man attempting
to execute the Heimlich Maneuver.
Except that he had his hands
below the big man’s navel, not on his
solar plexus where you need to press.
The big man was white as a sheet.

There was no time to be tactful.
“Please step aside what you are
doing is not going to work.”
I placed my hand on his shoulder,
and he stepped away.

I asked him “Can you cough?”
The big guy shook his head no.
“Don’t worry I’m going to help you.”
He looked at me with terror in his eyes.

I stood behind the big guy,
whose name I later learned was Tom.
I reached around and put my left fist
in front of Tom’s solar plexus and then
I rotated it so that my thumb was
right up under his ribs. Then I placed
my right hand over my left and then
I tried to squeeze as hard as I could.

But it was of no use. Tom’s enormous
bulk meant my arms were fully
extended. I couldn’t manage to apply
sufficient pressure to dislodge whatever
was stuck in his windpipe. I had to think
and I had to think fast as to what to do.

A woman appeared in front of us.
“I’m a nurse—he needs to drink water.”
She held out a cup of water to Tom.
“Go away! He’s choking! He can’t drink!
That will only make things worse!”
(In the back of my mind I wondered
What the hell they are teaching
in nursing school these days?!)

“Don’t worry Tom-I’ve got you.”
His color had gone from white to blue
and was headed toward purple.
I told him not to worry-more as a
way to reassure myself because
I was sore afraid he was going to die.

I moved around in front of him.
Placed the heel of my right palm
directly under his ribs and squatted low.
Then using my legs, I thrust upward
with everything that I had. I thought for
sure this would work. But after 47 squats
and 47 thrusts Tom still couldn’t breathe
freely and his color made me queasy.
Somehow though he was conscious.
“Point to where it feels stuck.” Tom
indicated the area of his thymus. I placed
one hand on his back and the other on
his chest. Then drawing on my chi
reserves, I attempted to bring my hands
together inside his chest. It was more of
an energetic squeeze than a physical
one as l literally willed whatever was
stuck in there to loosen and dislodge.

It was my last play–I was spent. My
knees were shaking and I was
exhausted. My legs felt like jelly I thought
I was going to pass out But it worked!

Suddenly Tom gave hoarse cough
And the food flew from his mouth
He started to breathe again!
Halle-freakin-lujah!
I felt my adrenaline start to ebb.

A woman who had been watching the
whole thing took me by the shoulders.
She had kind and sad eyes and a really
lovely smile. “Oh my god! You saved his
life! You saved this party! Imagine if he
had died! Everyone would be so
distraught.” I burst into tears and she
pulled me to her and gave me a hug.

Not two minutes later, the paramedics
arrived. They gave Tom a thorough going
over and decided that he was well
enough to stay at the party.

I’ve discovered over the years that this is
how I am. For whatever reason, I’m
good in a crisis. Time telescopes for me.
Everything slows down and I seem to
see clearly what needs to be done.
And I do it. Only once it’s over, and the
danger has passed do I take in the
reality of what’s occurred. In this case,
it was the hindsight of knowing that I
literally had this man’s life in the palm of
my hand that shook me to my core.

When the crisis is over is when I am apt
to fall apart. As I did when that woman
Spoke and acknowledged my efforts.

Later my wife found me. She was inside
the whole time and she had no idea of
what transpired. She told me she’d be
the designated driver. She handed me
a glass of wine - enjoy, you earned it!

I saw Tom again at Michael’s party the
following year. He looked right through
me and he walked right past me. My
face clearly did not register for him.

I didn’t take it personally. We were both
in an altered reality on that hot summer
day in 2018 when I managed to prevent
his death by choking.

Ken Homer • March 2024

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

