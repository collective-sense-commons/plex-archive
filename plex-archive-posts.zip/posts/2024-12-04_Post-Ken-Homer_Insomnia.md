---
title: "Insomnia"
author: "Ken Homer"
issue_slug: "2024-12-04"
tags: []
---

# Insomnia

**Author:** [[Ken Homer]]
**Issue:** [2024-12-04](https://plex.collectivesensecommons.org/2024-12-04/)

---

## Insomnia
by **Ken Homer**

I wake night after night
Cold sweat soaking the hair on my chest
The creases of my elbows and the back of my neck
I’m shivering in the dampness of the sheets

I go into the bathroom
Towel myself dry
Empty my bladder
Return to bed
Turn the pillow over to the dry side
Try to find slumber once more

Gripped by a nausea I’ve felt since the election
My stomach knots with a fear I struggle to keep at bay
The shouting of my ancestors roils my thoughts:
Is this shit really going to happen again?!
The doleful eyes of the unborn appear before me:
What will be left for us when it’s our time to live?

Sleep is nowhere to be found
My mind’s engulfed by a dark foreboding
I stare into the abyss of fascism’s future/history
Hell is empty and all the devils are here–again
My country, O my country
Whither goest thou?

Ken Homer • November 2024

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

