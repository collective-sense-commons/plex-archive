---
title: "RedCan Graffiti Jam"
author: "Todd Hoskins"
issue_slug: "2023-12-06"
tags: []
---

# RedCan Graffiti Jam

**Author:** [[Todd Hoskins]]
**Issue:** [2023-12-06](https://plex.collectivesensecommons.org/2023-12-06/)

---

## RedCan Graffiti Jam
by **Todd Hoskins**

I shot these photos of the [RedCan Graffiti Jam](https://lakotayouth.org/redcan/) in October at a [Tribal Broadband Bootcamp](https://tribalbroadbandbootcamp.org/) (TBB) on the Cheyenne River Sioux reservation. The Cheyenne River Sioux Telephone Authority, the host of this bootcamp with over a dozen tribes present, is the oldest tribal telecom in North America having formed in 1958. This was my fifth TBB in the past eighteen months representing the [Tribal Resource Center](https://tribalresourcecenter.net/) and [People-Centered Internet](https://peoplecentered.net/).

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Todd Hoskins]] (author)
- [[2023]] (year)
- Topics: 

