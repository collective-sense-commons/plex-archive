---
title: "Life Path Collage"
author: "Judith Benham"
issue_slug: "2022-06-15"
tags: []
---

# Life Path Collage

**Author:** [[Judith Benham]]
**Issue:** [2022-06-15](https://plex.collectivesensecommons.org/2022-06-15/)

---

## Life Path Collage
by **Judith Benham**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Judith Benham]] (author)
- [[2022]] (year)
- Topics: 

