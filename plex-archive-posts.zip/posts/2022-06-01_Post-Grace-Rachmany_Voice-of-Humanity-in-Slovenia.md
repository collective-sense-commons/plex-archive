---
title: "Voice of Humanity in Slovenia"
author: "Grace Rachmany"
issue_slug: "2022-06-01"
tags: []
---

# Voice of Humanity in Slovenia

**Author:** [[Grace Rachmany]]
**Issue:** [2022-06-01](https://plex.collectivesensecommons.org/2022-06-01/)

---

## Voice of Humanity in Slovenia
by **Grace Rachmany**

A discussion over dinner about **resource-based economy** and the possibility of having **Ukrainian refugees** retrained for **Web3 development** in an **eco-village setting** led to a joyful week of property-hunting in Slovenia with a friend including consumption of **extremely local and excellent wine.**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Grace Rachmany]] (author)
- [[2022]] (year)
- Topics: 

