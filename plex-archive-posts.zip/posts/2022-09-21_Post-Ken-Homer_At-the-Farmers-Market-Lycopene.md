---
title: "At the Farmers Market Lycopene, Carotenoids, and Anthocyanin"
author: "Ken Homer"
issue_slug: "2022-09-21"
tags: []
---

# At the Farmers Market Lycopene, Carotenoids, and Anthocyanin

**Author:** [[Ken Homer]]
**Issue:** [2022-09-21](https://plex.collectivesensecommons.org/2022-09-21/)

---

## At the Farmers' Market: Lycopene, Carotenoids, and Anthocyanin
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2022]] (year)
- Topics: 

