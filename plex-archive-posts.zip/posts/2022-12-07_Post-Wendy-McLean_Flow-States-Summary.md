---
title: "Flow States Summary"
author: "Wendy McLean"
issue_slug: "2022-12-07"
tags: []
---

# Flow States Summary

**Author:** [[Wendy McLean]]
**Issue:** [2022-12-07](https://plex.collectivesensecommons.org/2022-12-07/)

---

## Flow States Summary
by **Wendy McLean**

*[Image not included in the current archive. Images may be included in the future.]*

I compiled a **summary of my research on Flow states**.  This first pass is already very compelling.  Much of the science shared in this summary echoes many conversations that have been happening around engagement, self-actualization and group coherence!

---

**Related:**
- [[Wendy McLean]] (author)
- [[2022]] (year)
- Topics: 

