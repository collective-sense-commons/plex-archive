---
title: "Kramers DC"
author: "Peter Kaminski"
issue_slug: "2024-05-15"
tags: []
---

# Kramers DC

**Author:** [[Peter Kaminski]]
**Issue:** [2024-05-15](https://plex.collectivesensecommons.org/2024-05-15/)

---

## Kramers DC
by **Peter Kaminski**

My wife Johanne and I were visiting DC earlier this week, and we got together with Stacey Druss, Mike Nelson, and Michael Lennon for a wonderful OGM-style conversation at Kramers, an iconic bookstore and cafe in Washington D.C.'s Dupont Circle neighborhood. 

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Peter Kaminski]] (author)
- [[2024]] (year)
- Topics: 

