---
title: "Earth and Art"
author: "Ken Homer"
issue_slug: "2024-09-18"
tags: []
---

# Earth and Art

**Author:** [[Ken Homer]]
**Issue:** [2024-09-18](https://plex.collectivesensecommons.org/2024-09-18/)

---

## Earth and Art
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

