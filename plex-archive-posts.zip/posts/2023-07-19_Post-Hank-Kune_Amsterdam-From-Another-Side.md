---
title: "Amsterdam From Another Side"
author: "Hank Kune"
issue_slug: "2023-07-19"
tags: []
---

# Amsterdam From Another Side

**Author:** [[Hank Kune]]
**Issue:** [2023-07-19](https://plex.collectivesensecommons.org/2023-07-19/)

---

## Amsterdam From Another Side
by **Hank Kune**

Outside its historic center, Amsterdam is like many other modern European capitals – expanding its horizons in all directions.

There are good reasons for visitors to avoid the historic center, and explore the streets of this *other side* of Amsterdam, a city which also has its more recent buildings, with artworks on the streets, and some surprising places to sit and reflect: *what was it I came here to see*?

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Hank Kune]] (author)
- [[2023]] (year)
- Topics: 

