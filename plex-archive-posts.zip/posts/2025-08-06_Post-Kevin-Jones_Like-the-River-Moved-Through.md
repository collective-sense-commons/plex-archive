---
title: "Like the River Moved Through"
author: "Kevin Jones"
issue_slug: "2025-08-06"
tags: []
---

# Like the River Moved Through

**Author:** [[Kevin Jones]]
**Issue:** [2025-08-06](https://plex.collectivesensecommons.org/2025-08-06/)

---

## Like the River Moved Through
by **Kevin Jones**

We are finally getting a place to live, post-Helene, in an apartment in the River Arts District of Asheville, at least for nine months. By then we should have figured out what to do with our farm and the house that was flooded.

Our dogs have been kept by some friends for the past three months while we travelled in Europe. I went by to talk to them today, and said we were moving to the apartment in about two weeks, where we could keep them again.

And somehow I felt the loss from the flood, the loss of our idyllic farm, when I was petting them, that I had not felt since the storm September 27th of last year. Touching my dog, opened that door to the feeling. It made me tired, but also glad, as it moved through me, like the river moved through what was my house.

---

**Related:**
- [[Kevin Jones]] (author)
- [[2025]] (year)
- Topics: 

