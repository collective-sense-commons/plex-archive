---
title: "Regenerative Finance Finance for a Regenerative Economy"
author: "Gil Friend"
issue_slug: "2023-06-07"
tags: []
---

# Regenerative Finance Finance for a Regenerative Economy

**Author:** [[Gil Friend]]
**Issue:** [2023-06-07](https://plex.collectivesensecommons.org/2023-06-07/)

---

## Regenerative Finance: Finance for a Regenerative Economy
by **Gil Friend**

### Online Course, Starts June 19
If you've been thinking about regenerative finance (and if you've been thinking about finance… and/or regeneration… then you should be!) then you want to take this course: [Regenerative Finance: Finance for a Regenerative Economy](https://capitalinstitute.org/course-finance-for-a-regenerative-economy/), from the Capital Institute. It begins June 19th.

Use promo code NATURALLOGIC10 to apply a 10% discount at checkout.

---

**Related:**
- [[Gil Friend]] (author)
- [[2023]] (year)
- Topics: 

