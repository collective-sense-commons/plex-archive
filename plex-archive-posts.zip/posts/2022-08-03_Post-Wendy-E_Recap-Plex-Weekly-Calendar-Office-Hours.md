---
title: "Recap Plex Weekly Calendar, Office Hours"
author: "Wendy E."
issue_slug: "2022-08-03"
tags: []
---

# Recap Plex Weekly Calendar, Office Hours

**Author:** [[Wendy E.]]
**Issue:** [2022-08-03](https://plex.collectivesensecommons.org/2022-08-03/)

---

## Recap: Plex Weekly Calendar, Office Hours
A quick reminder, the [**Plex Weekly Calendar**](__GHOST_URL__/calendar/) is a map showing recurring calls and when they fall during the week. There are community/project calls, and a new thing, [**Office Hours**](https://wiki.openglobalmind.com/ogm_culture/office_hours) – community members having regular drop-in meetings, some on a particular topic, some free-form. **Grace,** **Jerry,** and **Pete** are on the calendar now (see the list under the calendar grid for information about Jerry's Office Hours). **Jonathan** and **Wendy E.** expect to be on the calendar soon. You can be, too – just ping [Pete](mailto:kaminski@istori.com).

---

**Related:**
- [[Wendy E.]] (author)
- [[2022]] (year)
- Topics: 

