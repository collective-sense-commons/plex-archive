---
title: "Some Thoughts on Building New Habits"
author: "Ken Homer"
issue_slug: "2023-07-19"
tags: []
---

# Some Thoughts on Building New Habits

**Author:** [[Ken Homer]]
**Issue:** [2023-07-19](https://plex.collectivesensecommons.org/2023-07-19/)

---

## Some Thoughts on Building New Habits
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

