---
title: "Plex Conversations"
author: "Peter Kaminski"
issue_slug: "2024-06-19"
tags: []
---

# Plex Conversations

**Author:** [[Peter Kaminski]]
**Issue:** [2024-06-19](https://plex.collectivesensecommons.org/2024-06-19/)

---

## Plex Conversations
by **Peter Kaminski**

I am continuing a practice of having one-on-one conversations with members of the Plex intercommunities, with the goal of helping us all know each other better, and to think better together.

I invite you to also have a conversation with another person, inside or outside of the Plex, and to share the best parts of that conversation with all of us. Send me an email at [kaminski@istori.com](mailto:kaminski@istori.com).

Here is a conversation with Dave Witzel.

---

**Related:**
- [[Peter Kaminski]] (author)
- [[2024]] (year)
- Topics: 

