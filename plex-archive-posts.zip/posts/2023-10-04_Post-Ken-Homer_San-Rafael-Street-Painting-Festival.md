---
title: "San Rafael Street Painting Festival"
author: "Ken Homer"
issue_slug: "2023-10-04"
tags: []
---

# San Rafael Street Painting Festival

**Author:** [[Ken Homer]]
**Issue:** [2023-10-04](https://plex.collectivesensecommons.org/2023-10-04/)

---

## San Rafael Street Painting Festival
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

