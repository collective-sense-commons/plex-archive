---
title: "RIP Harrison Owen"
author: "Unknown"
issue_slug: "2024-03-20"
tags: ['Events and Gatherings']
---

# RIP Harrison Owen

**Author:** [[Unknown]]
**Issue:** [2024-03-20](https://plex.collectivesensecommons.org/2024-03-20/)

---

## RIP: Harrison Owen
Participants on the OGM List this week shared short remembrances of Owen Harrison and his influences on their lives. Harrison died on March 16, 2024 at the age of 88, from natural causes.

Harrison was particularly known for creating Open Space Technology, which is a deceptively simple approach to organizing meetings, used by Internet Identity Workshop, BarCamps, RecentChangesCamps, and many, many other organizations and gatherings.

Read more:

- [Harrison Owen has died](https://www.chriscorrigan.com/parkinglot/blog/) (Chris Corrigan)
- [Remembering Harrison Owen, 1935 – 2024](https://openspaceworld.org/wp2/) (Open Space World)

---

**Related:**
- [[Unknown]] (author)
- [[2024]] (year)
- Topics: [[Events and Gatherings]]

