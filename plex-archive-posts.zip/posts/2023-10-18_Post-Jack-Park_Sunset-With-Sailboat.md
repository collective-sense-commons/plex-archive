---
title: "Sunset With Sailboat"
author: "Jack Park"
issue_slug: "2023-10-18"
tags: []
---

# Sunset With Sailboat

**Author:** [[Jack Park]]
**Issue:** [2023-10-18](https://plex.collectivesensecommons.org/2023-10-18/)

---

## Sunset With Sailboat
by **Jack Park**

A sunset with sailboat looking towards the Philippines from Kona.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Jack Park]] (author)
- [[2023]] (year)
- Topics: 

