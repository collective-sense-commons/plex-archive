---
title: "Blake Garden"
author: "Ken Homer"
issue_slug: "2023-07-19"
tags: []
---

# Blake Garden

**Author:** [[Ken Homer]]
**Issue:** [2023-07-19](https://plex.collectivesensecommons.org/2023-07-19/)

---

## Blake Garden
by **Ken Homer**

Photos taken on a visit to [Blake Garden](https://ced.berkeley.edu/about-ced/our-spaces/blake-garden) in Kensington, California, near UC Berkeley.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

