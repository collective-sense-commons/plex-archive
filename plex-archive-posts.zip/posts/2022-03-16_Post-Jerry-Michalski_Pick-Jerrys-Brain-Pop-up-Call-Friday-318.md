---
title: "Pick Jerrys Brain Pop-up Call, Friday 318"
author: "Jerry Michalski"
issue_slug: "2022-03-16"
tags: ['Tools and Platforms']
---

# Pick Jerrys Brain Pop-up Call, Friday 318

**Author:** [[Jerry Michalski]]
**Issue:** [2022-03-16](https://plex.collectivesensecommons.org/2022-03-16/)

---

## “Pick Jerry’s Brain” Pop-up Call, Friday 3/18
Join **Jerry Michalski** this Friday, 3/18 at 11am PT for a pop-up Zoom to brainstorm marketing for PJB, at [https://us02web.zoom.us/j/4154650256?pwd=Zm5DWGRJcmFmZGtBMmI1Wkx2WUQyZz09](https://us02web.zoom.us/j/4154650256?pwd=Zm5DWGRJcmFmZGtBMmI1Wkx2WUQyZz09).

Jerry is launching **Pick Jerry’s Brain** as a way to make a living doing what he’s good at doing (think [Ikigai](https://en.wikipedia.org/wiki/Ikigai#Overview)). There is little doubt he would love your advice and leads, so please drop by!

---

**Related:**
- [[Jerry Michalski]] (author)
- [[2022]] (year)
- Topics: [[Tools and Platforms]]

