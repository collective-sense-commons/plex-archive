---
title: "Summary of Plex 1 March 2023"
author: "Unknown"
issue_slug: "2023-03-01"
tags: []
---

# Summary of Plex 1 March 2023

**Author:** [[Unknown]]
**Issue:** [2023-03-01](https://plex.collectivesensecommons.org/2023-03-01/)

---

## Summary of Plex: 1 March 2023
by **ChatGPT**

*Plex: 1 March 2023* covers a variety of topics, including an upcoming virtual workshop on biometrics and digital identity, the story of the two wolves and the importance of nurturing all parts of ourselves, the unique happiness and commitment to nature found in Costa Rica, concerns about the rush to develop AI for profit and the potential negative consequences, and a trip to Truckee, California. The article also includes information about weekly hosted calls and a coalition working to eliminate the Black tax on Black colleges' infrastructure bonds.

(Bonus update edition you're reading now includes two additional items: the OGM topic call on March 9th to explore the concept of a “digital home” containing all the information collected about us, which we can manage and share as we wish; and a new map called “Toward a Collaborative Ecosystem” available on Miro, regularly updated and aims to represent organizations, networks, and projects that can be of service to the whole collaborative ecosystem.)

---

**Related:**
- [[Unknown]] (author)
- [[2023]] (year)
- Topics: 

