---
title: "Buddha"
author: "Jack Park"
issue_slug: "2023-09-20"
tags: []
---

# Buddha

**Author:** [[Jack Park]]
**Issue:** [2023-09-20](https://plex.collectivesensecommons.org/2023-09-20/)

---

## Buddha
by **Jack Park**

A Buddha image I shot with my droid phone this morning (2023-09-18). It’s a ~3+ meter tall marble statue looking over the ocean at the Waikoloa Hilton north of Kona. (Image optimization by Peter Kaminski.)

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Jack Park]] (author)
- [[2023]] (year)
- Topics: 

