---
title: "Profusion"
author: "Ken Homer"
issue_slug: "2025-04-16"
tags: []
---

# Profusion

**Author:** [[Ken Homer]]
**Issue:** [2025-04-16](https://plex.collectivesensecommons.org/2025-04-16/)

---

## Profusion
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2025]] (year)
- Topics: 

