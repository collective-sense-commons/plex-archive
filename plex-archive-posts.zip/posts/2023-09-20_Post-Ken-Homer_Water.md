---
title: "Water"
author: "Ken Homer"
issue_slug: "2023-09-20"
tags: []
---

# Water

**Author:** [[Ken Homer]]
**Issue:** [2023-09-20](https://plex.collectivesensecommons.org/2023-09-20/)

---

## Water
by **Ken Homer**

Taken on hikes in March ’06 when we  had a wet winter.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2023]] (year)
- Topics: 

