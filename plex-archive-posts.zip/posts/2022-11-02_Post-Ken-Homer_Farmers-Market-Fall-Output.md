---
title: "Farmers Market Fall Output"
author: "Ken Homer"
issue_slug: "2022-11-02"
tags: []
---

# Farmers Market Fall Output

**Author:** [[Ken Homer]]
**Issue:** [2022-11-02](https://plex.collectivesensecommons.org/2022-11-02/)

---

## Farmer’s Market Fall Output
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2022]] (year)
- Topics: 

