---
title: "Map Weavers Update"
author: "Unknown"
issue_slug: "2022-06-15"
tags: []
---

# Map Weavers Update

**Author:** [[Unknown]]
**Issue:** [2022-06-15](https://plex.collectivesensecommons.org/2022-06-15/)

---

## Map Weavers Update
(this update was inadvertently left out of the initial publication of this issue, it will be added in soon. check back for updates tomorrow!)

---

**Related:**
- [[Unknown]] (author)
- [[2022]] (year)
- Topics: 

