---
title: "Pix from the Garden"
author: "Ken Homer"
issue_slug: "2024-08-21"
tags: []
---

# Pix from the Garden

**Author:** [[Ken Homer]]
**Issue:** [2024-08-21](https://plex.collectivesensecommons.org/2024-08-21/)

---

## Pix from the Garden
by **Ken Homer**

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2024]] (year)
- Topics: 

