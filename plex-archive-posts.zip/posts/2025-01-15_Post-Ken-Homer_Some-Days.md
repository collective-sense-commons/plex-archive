---
title: "Some Days..."
author: "Ken Homer"
issue_slug: "2025-01-15"
tags: ['Climate and Environment']
---

# Some Days...

**Author:** [[Ken Homer]]
**Issue:** [2025-01-15](https://plex.collectivesensecommons.org/2025-01-15/)

---

## Some Days...
by **Ken Homer**

I’m having a hard time writing anything worth reading right now. Despite only reading the headlines and not the stories, too much depressing info has seeped into my brain.

A man who has pledged to be a dictator on day one will be inaugurated in less than a week. The confirmation hearings of the worst possible candidates to fill roles that will greatly impact the immediate and long-term future of our planet are underway and are surreal.

I never thought I would live in such a world. A nominee for Secretary of Defense whose body is covered with white supremacist tattoos and thinks women don’t belong in combat units; a Secretary of Energy who denies climate change is fueling wildfires even as LA burns; a Secretary of HHS who is a vaccine denier, and on and on.

Some days it’s best not to look at the news…

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2025]] (year)
- Topics: [[Climate and Environment]]

