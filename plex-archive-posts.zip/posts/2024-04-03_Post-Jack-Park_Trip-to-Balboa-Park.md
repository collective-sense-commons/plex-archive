---
title: "Trip to Balboa Park"
author: "Jack Park"
issue_slug: "2024-04-03"
tags: []
---

# Trip to Balboa Park

**Author:** [[Jack Park]]
**Issue:** [2024-04-03](https://plex.collectivesensecommons.org/2024-04-03/)

---

## Trip to Balboa Park
by **Jack Park** and **Peter Kaminski**

Linda, Jack, Johanne, and Pete met up a couple of weeks ago at San Diego's Balboa Park, to see the seasonal cherry blossoms at the Japanese Friendship Garden and to ride the miniature train. Much fun was had! Here are a few of the highlights.

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Jack Park]] (author)
- [[2024]] (year)
- Topics: 

