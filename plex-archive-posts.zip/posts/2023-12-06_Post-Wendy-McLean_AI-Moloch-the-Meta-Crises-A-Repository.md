---
title: "AI, Moloch  the Meta Crises - A Repository"
author: "Wendy McLean"
issue_slug: "2023-12-06"
tags: []
---

# AI, Moloch  the Meta Crises - A Repository

**Author:** [[Wendy McLean]]
**Issue:** [2023-12-06](https://plex.collectivesensecommons.org/2023-12-06/)

---

## AI, Moloch & the Meta Crises - A Repository
by **Wendy McLean**

This year, I’ve been occasionally researching AI, capturing insights on how we might move forward in a responsible way. I’m cautiously optimistic.

My notes are now organized in Notion and [made public for everyone, in service to the Commons](https://everyoneswisdom.notion.site/AI-Moloch-the-Meta-Crises-9fb6382930a64db5bce509cbe1fd1e08?pvs=4), where you can view and comment.

I created a [collaborative page here](https://everyoneswisdom.notion.site/COLLABORATIVE-AI-Moloch-the-Meta-Crisis-26489b90cc8c49d1847abdfb932f3db3?pvs=4) if you want to work on this repository with me. As always, I welcome your collaboration.

Happy Hanukkah to those who celebrate!  ~ Wendy

---

**Related:**
- [[Wendy McLean]] (author)
- [[2023]] (year)
- Topics: 

