---
title: "OGM Mailing List"
author: "Unknown"
issue_slug: "2022-08-17"
tags: []
---

# OGM Mailing List

**Author:** [[Unknown]]
**Issue:** [2022-08-17](https://plex.collectivesensecommons.org/2022-08-17/)

---

## OGM Mailing List
If you're not already a subscriber, use this form to request subscription to the OGM Mailing List: [Joining the Open Global Mind conversation](https://docs.google.com/forms/d/e/1FAIpQLSfNY_K88JLK0FOSmV5ulYYYdX6_n_HZ9TARZM0RcsisZbrOSQ/viewform?usp=sf_link).

Stats: 229 members. Last two weeks: 27 active members, 158 messages, 63 threads.

The OGM mailing list is one of the core communication channels for Open Global Mind, and is a mix of announcements about various topics of interest to OGM members, and some spirited discussion and comments.

Top ten threads from the last two weeks:

- Next week's OGM session. A #BHAQ question to consider
- Nadia on Idea Machines (May'2022)
- Speaking of stacks
- Remembering William Moyer
- Economists not being scientists
- Climate episode on The Realignment podcast
- The new right isn't conservative. They don't want to be. | The Week
- The consciousness of bees - The Washington Post
- When Community Concerts Brought Don Shirley to Small Towns - The New York Times
- Will This Be An Asterisk* Election? | FiveThirtyEight

---

**Related:**
- [[Unknown]] (author)
- [[2022]] (year)
- Topics: 

