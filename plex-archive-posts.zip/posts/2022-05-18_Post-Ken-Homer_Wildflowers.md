---
title: "Wildflowers"
author: "Ken Homer"
issue_slug: "2022-05-18"
tags: []
---

# Wildflowers

**Author:** [[Ken Homer]]
**Issue:** [2022-05-18](https://plex.collectivesensecommons.org/2022-05-18/)

---

## Wildflowers
by **Ken Homer**

Something different: here are a few pix of an amazing event that took place in 2009. An office park hydroseeded 5 acres of wildflowers. There were literally hundreds of thousands of flowers everywhere you looked. I spent hours walking among them. And I can attest that being around that many flowers had a profound and positive effect on my psyche. I wish they would do it again, but instead they landscaped the place with different plants. Too bad, it was quite a trip! I did make a screensaver from a bunch of these and one day I was doing a presentation on a 15’ screen. I forgot the screensaver was on I left a slide up for a long time when it kicked in and people were like: Whoa! Where is that?!

(View on the web so you can click on each image to enlarge.)

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Ken Homer]] (author)
- [[2022]] (year)
- Topics: 

