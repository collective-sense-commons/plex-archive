---
title: "Top of Mind"
author: "Unknown"
issue_slug: "2022-04-06"
tags: []
---

# Top of Mind

**Author:** [[Unknown]]
**Issue:** [2022-04-06](https://plex.collectivesensecommons.org/2022-04-06/)

---

## Top of Mind
BPD asked some of the denizens of the Plex, “What is one word or phrase that’s important to you this week?”

Answers: **malaise–origins–buzzwords of the future–love–understand–slow–tripartite–overwhelm.**

Try it at home: what would your word be? How about asking the people you see every week?

---

**Related:**
- [[Unknown]] (author)
- [[2022]] (year)
- Topics: 

