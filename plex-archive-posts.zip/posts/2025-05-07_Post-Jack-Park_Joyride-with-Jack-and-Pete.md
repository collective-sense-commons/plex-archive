---
title: "Joyride with Jack and Pete"
author: "Jack Park"
issue_slug: "2025-05-07"
tags: []
---

# Joyride with Jack and Pete

**Author:** [[Jack Park]]
**Issue:** [2025-05-07](https://plex.collectivesensecommons.org/2025-05-07/)

---

## Joyride with Jack and Pete
by **Peter Kaminski**

Jack Park and Peter Kaminski took to the skies over sunny San Diego last month on a 30-minute helicopter tour. Jack had been gifted the tour and had a spare seat, which he graciously offered to Pete.

Jack’s been a pilot for many years, Pete is an aircraft buff, and we both had a wonderful time.

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

*[Image not included in the current archive. Images may be included in the future.]*

---

**Related:**
- [[Jack Park]] (author)
- [[2025]] (year)
- Topics: 

